<?php
// This file should not be executed
// All routing is handled by .htaccess
// If you're seeing this, disable this file on your server
header('HTTP/1.1 410 Gone');
echo 'This entry point is disabled. Use .htaccess routing instead.';
exit;
?>

